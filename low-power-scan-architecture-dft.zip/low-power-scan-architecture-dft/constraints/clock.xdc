## clock.xdc
## Author : Kartik Mishra
## Timing constraint for the 100 MHz target used in the project (period = 10 ns).
## Works for both accumulator_scan (Phase 1) and low_power_acc (Phase 2); the clock port is named "clk".

create_clock -name clk -period 10.000 -waveform {0.000 5.000} [get_ports clk]

## Pin assignments (set_property PACKAGE_PIN / IOSTANDARD) depend on the target board and are
## not included here. They are not needed for synthesis, implementation, timing or power reports.
