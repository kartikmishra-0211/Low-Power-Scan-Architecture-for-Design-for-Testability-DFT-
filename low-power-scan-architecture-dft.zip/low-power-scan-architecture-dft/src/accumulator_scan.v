//=============================================================================
// accumulator_scan.v
// Author : Kartik Mishra
// Phase 1: 4-bit accumulator with one full scan chain (baseline)
//=============================================================================
module accumulator_scan(
    input clk, reset, scan_en, scan_in,
    input [3:0] data_in,
    output [3:0] acc_out,
    output scan_out
);
// Internal wires
wire [3:0] q;
wire [3:0] sum;

// Adder Logic
assign sum = q + data_in;

// Scan Flip Flops Instantiation
// FF0
scan_dff ff0 (.clk(clk), .reset(reset), .se(scan_en), .si(scan_in), .d(sum[0]), .q(q[0]));
// FF1 connected to FF0
scan_dff ff1 (.clk(clk), .reset(reset), .se(scan_en), .si(q[0]), .d(sum[1]), .q(q[1]));
// FF2 connected to FF1
scan_dff ff2 (.clk(clk), .reset(reset), .se(scan_en), .si(q[1]), .d(sum[2]), .q(q[2]));
// FF3 connected to FF2
scan_dff ff3 (.clk(clk), .reset(reset), .se(scan_en), .si(q[2]), .d(sum[3]), .q(q[3]));

assign acc_out = q;
assign scan_out = q[3];
endmodule
