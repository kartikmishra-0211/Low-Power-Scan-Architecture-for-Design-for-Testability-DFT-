//=============================================================================
// low_power_acc.v
// Author : Kartik Mishra
// Phase 2: 4-bit accumulator with a partitioned scan chain
//          Sub-chain 1 = FF0, FF1    Sub-chain 2 = FF2, FF3
//          A 2-bit counter enables only one sub-chain at a time while shifting.
//=============================================================================
module low_power_acc(
    input clk, reset, scan_en, scan_in,
    input [3:0] data_in,
    output [3:0] acc_out,
    output scan_out
);
wire [3:0] q;
wire [3:0] sum;
reg [1:0] counter;
wire enable_group1, enable_group2;

// Counter Logic
always @(posedge clk or posedge reset) begin
    if (reset) counter <= 0;
    else if (scan_en) counter <= counter + 1;
    else counter <= 0;
end

// Sub-chain enables
assign enable_group1 = (counter[1] == 0) && scan_en;
assign enable_group2 = (counter[1] == 1) && scan_en;

// Adder
assign sum = q + data_in;

// Partitioned Instantiation
// Group 1: Active when enable_group1 is HIGH
scan_dff_controlled ff0 (.clk(clk), .en(enable_group1), .se(scan_en), .si(scan_in), .d(sum[0]), .q(q[0]));
scan_dff_controlled ff1 (.clk(clk), .en(enable_group1), .se(scan_en), .si(q[0]),    .d(sum[1]), .q(q[1]));
// Group 2: Active when enable_group2 is HIGH
scan_dff_controlled ff2 (.clk(clk), .en(enable_group2), .se(scan_en), .si(scan_in), .d(sum[2]), .q(q[2]));
scan_dff_controlled ff3 (.clk(clk), .en(enable_group2), .se(scan_en), .si(q[2]),    .d(sum[3]), .q(q[3]));

assign acc_out = q;

// Muxing scan out based on active group
assign scan_out = (counter[1] == 0) ? q[1] : q[3];
endmodule
