//=============================================================================
// scan_dff.v
// Author : Kartik Mishra
// Project: Low Power Scan Architecture for Design for Testability (DFT)
//
// Contains two modules:
//   1. scan_dff            - Mux-D scan flip-flop used by the Phase 1 baseline
//                            (taken from the report appendix).
//   2. scan_dff_controlled - Scan flip-flop with a shift-enable input, used by the
//                            Phase 2 partitioned design. NOTE: this module is
//                            instantiated in the report appendix but its source is
//                            not printed there. It was written to match the behaviour
//                            described in Section 4.4 of the report.
//=============================================================================

// Scan D flip-flop (Phase 1)
module scan_dff(
    input clk, reset, se, si, d,
    output reg q
);
always @(posedge clk or posedge reset) begin
    if (reset)
        q <= 1'b0;
    else if (se)
        q <= si;   // Scan Mode
    else
        q <= d;    // Functional Mode
end
endmodule

// Scan D flip-flop with sub-chain enable (Phase 2)
//   se = 0 : functional mode, always captures d (normal accumulation)
//   se = 1 : scan mode, shifts in si only when en = 1, otherwise holds its value
module scan_dff_controlled(
    input clk, en, se, si, d,
    output reg q
);
initial q = 1'b0;   // power-up value (the instantiation in low_power_acc has no reset pin)

always @(posedge clk) begin
    if (se) begin
        if (en)
            q <= si;   // this sub-chain is active: shift
        // else: hold, no switching in this sub-chain
    end else begin
        q <= d;        // functional mode
    end
end
endmodule
